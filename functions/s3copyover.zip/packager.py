import os
import sys
import platform
import zipfile
import subprocess
import time
import hashlib
import shutil

import virtualenv

IGNORE_ZIP_FOLDERS = [".DS_Store", ".deployments", ".idea", ".osl", ".venv"]
ZIP_FILE_NAME = "lambda_deployment.zip"


if platform.system() == 'Windows':
    def pip_script_in_venv(venv_dir):
        # type: (str) -> str
        pip_exe = os.path.join(venv_dir, 'Scripts', 'pip.exe')
        return pip_exe

    def site_packages_dir_in_venv(venv_dir):
        # type: (str) -> str
        deps_dir = os.path.join(venv_dir, 'Lib', 'site-packages')
        return deps_dir

else:
    # Posix platforms.
    def pip_script_in_venv(venv_dir):
        # type: (str) -> str
        pip_exe = os.path.join(venv_dir, 'bin', 'pip')
        return pip_exe

    def site_packages_dir_in_venv(venv_dir):
        # type: (str) -> str
        python_dir = os.listdir(os.path.join(venv_dir, 'lib'))[0]
        deps_dir = os.path.join(venv_dir, 'lib', python_dir, 'site-packages')
        return deps_dir


def _create_virtualenv(venv_dir):
    original = sys.argv
    sys.argv = ['', venv_dir, '--quiet']
    try:
        virtualenv.main()
    finally:
        sys.argv = original

def create_deployment_package(project_dir, zip_filename):
    print "Creating deployment package."
    venv_dir = os.path.join(project_dir, '.venv')
    _create_virtualenv(venv_dir)
    pip_exe = pip_script_in_venv(venv_dir)
    assert os.path.isfile(pip_exe)
    
    # Next install any requirements specified by the app.
    requirements_file = os.path.join(project_dir, 'requirements.txt')
    deployment_package_filename = "/tmp/" + zip_filename

    if os.path.isfile(deployment_package_filename):
        os.remove(deployment_package_filename)
        
    if _has_at_least_one_package(requirements_file):
        p = subprocess.Popen([pip_exe, 'install', '--upgrade', '-r', requirements_file], stdout=subprocess.PIPE)
        p.communicate()
        deps_dir = site_packages_dir_in_venv(venv_dir)
        assert os.path.isdir(deps_dir)
        
        with zipfile.ZipFile(deployment_package_filename, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            _add_py_deps(z, deps_dir)
            _add_app_files(z, project_dir)
    return deployment_package_filename

def _has_at_least_one_package(filename):
    if not os.path.isfile(filename):
        return False
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                return True
    return False

    
def _add_py_deps(zip, deps_dir):
    prefix_len = len(deps_dir) + 1
    for root, dirnames, filenames in os.walk(deps_dir):
        if root == deps_dir and 'chalice' in dirnames:
                # Don't include any chalice deps.  We cherry pick
                # what we want to include in _add_app_files.
                dirnames.remove('chalice')
        for filename in filenames:
            full_path = os.path.join(root, filename)
            zip_path = full_path[prefix_len:]
            zip.write(full_path, zip_path)

def _add_app_files(zip, project_dir):
    abs_src = os.path.abspath(project_dir)
    for root, dirs, files in os.walk(project_dir):
        ignore = False
        for folder_name in IGNORE_ZIP_FOLDERS:
            if "/" + folder_name in root:
                ignore=True

        if ignore:
            continue
        for filename in files:
            print("Adding {}".format(os.path.join(root, filename)))
            zip.write(os.path.join(root, filename), filename)



lambda_source_dir = os.getcwd()
final_zip_location = os.path.join(lambda_source_dir, os.path.basename(ZIP_FILE_NAME))
if os.path.isfile(final_zip_location):
    os.remove(final_zip_location)

zip_filename = create_deployment_package(lambda_source_dir, ZIP_FILE_NAME)
os.rename(zip_filename, final_zip_location)